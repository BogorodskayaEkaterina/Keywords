import tkinter as tk
from tkinter import ttk, filedialog
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt
import matplotlib.backends.backend_tkagg as tkagg
from PIL import Image, ImageTk
import numpy as np
import random
import os

words_list = [
    'Архангельск', 'туры', 'отдых', 'Россия', 'Каникулы', 'Путешествия', 'Отели',
    'курорты', 'Экскурсии', 'Поляна', 'Сочи', 'Москва', 'Петербург', 'Карелия',
    'Байкал', 'Алтай', 'Екатеринбург', 'Казань', 'Ярославль', 'кольцо', 'отдых', 'отдых',
    'Природа', 'Туры', 'ярмарки', 'зима', 'Катание', 'источники',
    'туры', 'сияние', 'Мурманск', 'Хибины', 'программы', 'Мороз', 'места',
    'Традиции', 'кухня', 'Фотосессии', 'экскурсии', 'достопримечательности', 'Шопинг',
    'отдых', 'мероприятия', 'Прокат', 'Транспорт', 'Виза', 'Бронирование',
    'Акции', 'Отзывы', 'Безопасность', 'каникулы', 'Россия', 'каникулы', 'курорт', 'елка', 
    'горы', 'шубы', 'мандарины', 'снеговики', 'метель', 'путешествие', 'мороз', 'сани',
    'Снегурочка', 'масленица', 'корпоратив', 'отдых', 'настроение',
    'каникулы', 'двор', 'каток', 'баня', 'сезон', 'сказка',
    'сувениры', 'поездка', 'отдых', 'мультфильмы', 'игры', 'ужин',
    'подарок', 'путешествие', 'воздух', 'сказка', 'базар',
    'Тропинка', 'Санки', 'снеговики', 'Мандарины', 'оливье', 'Каток', 'фейерверк',
    'Прогулка', 'фонари', 'шарфы', 'варежки',
    'мультфильмы', 'фильмы', 'горки', 'баталии',
    'гуляния', 'ярмарка', 'праздник',
    'Путешествие', 'огни', 'отель', 'горы', 'Поездка', 'курорт',
    'вечеринка', 'коттедже', 'Серпантин', 'подарки', 'елка', 'Купание', 'бане',
    'карнавал', 'площади'
]


# Функция для генерации облака слов
def generate_wordcloud():
    shape = shape_var.get()
    mask = None

    if shape == "circle":
        mask = np.array(Image.new('RGB', (240, 240), (255,255,255)))
        x, y = np.ogrid[:240, :240]
        mask_array = (x - 120)**2 + (y - 120)**2 > 110**2
        mask[mask_array] = [255, 255, 255]
        mask[~mask_array] = [0, 0, 0]

    elif shape == "heart":
        try:
            mask = np.array(Image.open("heart.png"))
            mask = mask[:, :, 0]
        except FileNotFoundError:
            label.config(text="Файл heart.png не найден.")
            return

    elif shape == "russia":
        try:
            mask = np.array(Image.open("russia1.jpg"))
            mask = mask[:, :, 0]
        except FileNotFoundError:
            label.config(text="Файл russia.jpg не найден.")
            return
    elif shape == "tree":
        try:
            mask = np.array(Image.open("tree.png"))
            mask = mask[:, :, 0]
        except FileNotFoundError:
            label.config(text="Файл tree.png не найден.")
            return
    elif shape == "star":
        try:
            mask = np.array(Image.open("star.png"))
            mask = mask[:, :, 0]
        except FileNotFoundError:
            label.config(text="Файл star.png не найден.")
            return


    # Выбор случайной части слов из списка
    random_words = random.sample(words_list, k=min(len(words_list), 30))  # Выбираем до 30 случайных слов
    text = " ".join(random_words)

    try:
        wordcloud = WordCloud(
            width=240,  # Уменьшаем ширину облака слов
            height=240,  # Уменьшаем высоту облака слов
            margin=0,
            background_color="white",
            mask=mask,
            stopwords=STOPWORDS
        ).generate(text)

        image = wordcloud.to_image()
        image.save("wordcloud.png") # сохранение в файл
        photo = ImageTk.PhotoImage(image)
        label.config(image=photo)
        label.image = photo
        label.config(text="")
        save_button.config(state="normal") #активируем кнопку сохранения после генерации

    except Exception as e:
        label.config(text=f"Ошибка: {e}")
    
    

def save_wordcloud():
    try:
        filepath = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG images", "*.png")])
        if filepath:
            image = Image.open("wordcloud.png")
            image.save(filepath)
    except Exception as e:
        label.config(text=f"Ошибка при сохранении: {e}")

# Создаем главное окно
root = tk.Tk()
root.title("Облако слов")
root.geometry("600x500")  # Изменяем размер окна под меньшее изображение



# Настраиваем стили кнопок
style = ttk.Style()
style.configure("TButton", padding=6, relief="flat", background="#4CAF50", foreground="black", font=("Helvetica", 11))
style.configure("TRadiobutton", 
                background="#f0f0f0", # Светло-серый фон
                foreground="#333333", # Темно-серый текст
                padding=(10, 5), # Добавление отступов
                relief="raised",  # Поднятый рельеф
                font=("Arial", 12) # Шрифт
               )

# Метка для вывода результата
label = ttk.Label(root)
label.pack(pady=20)

# Фрейм для радиокнопок выбора формы
frame = ttk.Frame(root)
frame.pack(pady=15)

# Переменная для хранения значения выбранной формы
shape_var = tk.StringVar(value="square")


# Радиокнопки для выбора формы
ttk.Radiobutton(frame, text="Квадрат", variable=shape_var, value="square").pack(side=tk.LEFT)
ttk.Radiobutton(frame, text="Круг", variable=shape_var, value="circle").pack(side=tk.LEFT)
ttk.Radiobutton(frame, text="Сердце", variable=shape_var, value="heart").pack(side=tk.LEFT)
ttk.Radiobutton(frame, text="Россия", variable=shape_var, value="russia").pack(side=tk.LEFT)
ttk.Radiobutton(frame, text="Ёлка", variable=shape_var, value="tree").pack(side=tk.LEFT)
ttk.Radiobutton(frame, text="Звезда", variable=shape_var, value="star").pack(side=tk.LEFT)

# Основная кнопка для создания облака слов
button = ttk.Button(root, text="Создать облако", command=generate_wordcloud, style="TButton")
button.pack(pady=15)

# Кнопка сохранения (добавлена)
save_button = ttk.Button(root, text="Сохранить изображение", command=save_wordcloud, style="TButton", state="disabled") #начальное состояние - disabled
save_button.pack(pady=10)

# Запуск главного цикла
root.mainloop()